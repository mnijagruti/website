/**
 ******************************************************************************
 *
 * @file        MG82F6D64_INT_VECTOR.H
 *
 * @brief       This is the C code format driver head file.
 *
 * @par         Project
 *              MG82F6D64
 * @version     V1.00
 * @date        2020/09/18
 * @copyright   Copyright (c) 2019 MegaWin Technology Co., Ltd.
 *              All rights reserved.
 *
 ******************************************************************************
 * @par         Disclaimer
 *      The Demo software is provided "AS IF"  without any warranty, either
 *      expressed or implied, including, but not limited to, the implied warranties
 *      of merchantability and fitness for a particular purpose.  The author will
 *      not be liable for any special, incidental, consequential or indirect
 *      damages due to loss of data or any other reason.
 *      These statements agree with the world wide and local dictated laws about
 *      authorship and violence against these laws.
 ******************************************************************************
 ******************************************************************************
 */


#ifndef _MG82F6D64_INT_VECTOR_H
#define _MG82F6D64_INT_VECTOR_H

////!@{
////! defgroup interrupt service routine source Define
#define INT0_ISR_VECTOR           0
#define TIMER0_ISR_VECTOR         1
#define INT1_ISR_VECTOR           2
#define TIMER1_ISR_VECTOR         3
#define S0_ISR_VECTOR             4
#define TIMER2_ISR_VECTOR         5
#define INT2_ISR_VECTOR           6
#define SPI_ISR_VECTOR            7
#define ADC_ISR_VECTOR            8
#define PCA0_ISR_VECTOR           9
#define SYSFLAG_ISR_VECTOR        10
#define KBI_ISR_VECTOR            11
#define I2C0_ISR_VECTOR           12
#define AC0_ISR_VECTOR            13
#define S1_ISR_VECTOR             14
#define INT3_ISR_VECTOR           15
#define TIMER3_ISR_VECTOR         16
#define AC1_ISR_VECTOR            17
#define DMA_ISR_VECTOR            18
#define AC2_ISR_VECTOR            19
#define S2_ISR_VECTOR             20
#define TIMER4_ISR_VECTOR         21
#define S3_ISR_VECTOR             22
#define I2C1_ISR_VECTOR           23

#endif
